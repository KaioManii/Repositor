PIXEL RUNNER — projeto Android leve
===================================
O projeto contém um jogo original em HTML/Canvas dentro de um WebView, sem assets externos e jogável offline.

Como gerar o APK:
1. Abra a pasta no Android Studio (com Android SDK instalado) e aguarde a sincronização Gradle.
2. Use Build > Build APK(s).
3. O APK debug aparecerá em app/build/outputs/apk/debug/app-debug.apk.

Alternativa pela nuvem:
1. Crie um repositório GitHub e envie todos os arquivos desta pasta.
2. Abra Actions > Build Pixel Runner APK > Run workflow.
3. Baixe o artefato PixelRunner-debug-apk quando a execução terminar.

Observação: este ambiente não possui Android SDK/Gradle, então não foi possível compilar nem verificar um APK aqui. Não instale um APK de origem desconhecida.
